cd $(dirname $0)
rm -f GoL
rm -rf build
